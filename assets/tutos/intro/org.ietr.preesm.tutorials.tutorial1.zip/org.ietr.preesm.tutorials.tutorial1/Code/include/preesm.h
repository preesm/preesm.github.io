
#ifndef PREESM_H
#define PREESM_H

#include "testcom.h"

#define LOOP_SIZE 20

typedef unsigned char uchar;

#endif
