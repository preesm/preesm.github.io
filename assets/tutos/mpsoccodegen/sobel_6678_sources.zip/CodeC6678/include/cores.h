/*
 * cores.h
 *
 *  Created on: 2013.08.02
 *      Author: Karol
 */

#ifndef CORES_H_
#define CORES_H_

#include "c6678.h"

typedef unsigned char uchar;

#define CORE0
void core0(void);
#define CORE1
void core1(void);
#define CORE2
void core2(void);
#define CORE3
void core3(void);
#define CORE4
void core4(void);
#define CORE5
void core5(void);
#define CORE6
void core6(void);
#define CORE7
void core7(void);


#endif /* CORES_H_ */
