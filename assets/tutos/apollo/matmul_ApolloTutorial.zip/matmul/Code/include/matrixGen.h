/*
	============================================================================
	Name        : matrixGen.h
	Author      : rlazcano
	Version     : 1.0
	Copyright   : CeCILL-C ?
	Description : matrix generator
	============================================================================
*/

#ifndef MATRIXGEN_H
#define MATRIXGEN_H

#include "preesm.h"

/**
* Function to generate random matrices
*
* @param rows
*        Number of rows
* @param cols
*        Number of columns
* @param matrix
*	 Generated matrix
*/
void matrixGen(int rows, int cols, OUT double *matrix);

#endif
