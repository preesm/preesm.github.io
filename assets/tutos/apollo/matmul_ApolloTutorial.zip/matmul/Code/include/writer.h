/*
	============================================================================
	Name        : writer.h
	Author      : rlazcano
	Version     :
	Copyright   :
	Description : Save results
	============================================================================
*/
#ifndef WRITER_H
#define WRITER_H

#include "preesm.h"

#define PATHOUT_BIN "../../dat/result.bin"

#define PATHOUT_TXT "../../dat/result.bin"

/**
* Function to save the results
*
* @param rows
*        the rows of the matrix
* @param cols
*        the columns of the matrix
* @param result
*        Matrix
*/

void saveResults(int rows, int cols, IN double *result);

#endif
