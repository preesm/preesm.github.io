/*
	============================================================================
	Name        : matrixMult.h
	Author      : rlazcano
	Version     : 1.0
	Copyright   : CeCILL-C ?
	Description : matrix multiplication
	============================================================================
*/

#ifndef MATRIXMULT_H
#define MATRIXMULT_H

#include "preesm.h"

/**
* Function to multiply two matrices
*
* @param rowsA
*        Number of rows of matrix A
* @param colsA
*        Number of columns of matrix A
* @param rowsB
*        Number of rows of matrix B
* @param colsB
*        Number of columns of matrix B
* @param A
*        Matrix A
* @param B
*        Matrix B
* @param mult
*	 Resulting matrix
*/
void matrixMult(int rowsA, int colsA, int rowsB, int colsB,IN double *A, IN double *B, OUT double *mult);

#endif
