/*
	============================================================================
	Name        : matrixGen.c
	Author      : rlazcano
	Version     : 1.0
	Copyright   : CECILL-C
	Description : matrix generator
	============================================================================
*/

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "matrixGen.h"

void matrixGen(int rows, int cols, double *matrix){
	printf("Starting\n");
	int opt;
	/*if(cols == 1000){
		opt = 1;
	}else{
		opt = 0;
	}*/
	opt = 0;
	for (int i = 0; i < rows; i++) {
	    for (int j = 0; j < cols; j++) {
			if(opt == 0){
				matrix[i*cols+j] = (double)((rows*(i/50) + cols*(j/20))/((rows-i) + (cols-j)));
			}else{
				matrix[i*cols+j] = (double)((rows*(i/100) + cols*(j/5))/((cols-i) - (rows-j)));
			}      
	    }
	}
	printf("End of matrixGen\n");
}
