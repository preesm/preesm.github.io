/*
	============================================================================
	Name        : matrixMult.c
	Author      : rlazcano
	Version     : 1.0
	Copyright   : CECILL-C
	Description : matrix multiplication
	============================================================================
*/

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h> 
#include <sys/time.h>

#include "matrixMult.h"
	
void matrixMult(int rowsA, int colsA, int rowsB, int colsB, double *A, double *B, double *mult){
	/* ======== Matrix multiplication =====//===== C = A * B ============= */
	int i, j, k;
    unsigned int time = 0;

    struct timeval t1, t2;

	gettimeofday(&t1, NULL);
	printf("Starting mult\n");

	#ifdef APOLLO_AVAILABLE
	#pragma apollo dcop
	{
	#endif
		for (i = 0; i < rowsA; i++) {
			for (j = 0; j < colsB; j++) {
				mult[i*colsB + j] = 0.0;
				for (k = 0; k < colsA; k++) {
					mult[i*colsB + j] += A[i*colsA+k] * B[k*colsB+j];   
				}
			}
		}
	#ifdef APOLLO_AVAILABLE
	}
	#endif

	printf("end mult\n");
	gettimeofday(&t2, NULL);
	time = (t2.tv_sec - t1.tv_sec) * 1000.0;      // sec to ms
    time += (t2.tv_usec - t1.tv_usec) / 1000.0;
	
	printf("\nTime: %d ms\n", time);
}

