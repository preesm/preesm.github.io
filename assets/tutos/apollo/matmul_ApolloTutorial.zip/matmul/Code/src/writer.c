/*
	============================================================================
	Name        : writer.c
	Author      : rlazcano
	Version     :
	Copyright   : CECILL-C
	Description : Save results
	============================================================================
*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "writer.h"

static FILE *ptfile ;
static FILE *fp;

void saveResults(int rows, int cols, double *result)
{
	int i;
	int j;
	
	ptfile = fopen(PATHOUT_BIN, "wb");
    	fwrite(result, sizeof(float), rows * cols, ptfile);
    	fclose(ptfile);

	fp = fopen(PATHOUT_TXT,"w"); //Fichero de salida

	for(i = 0; i < rows; i++){
		for (j = 0; j < cols; j++){
			fprintf(fp,"%f\n",result[i*cols + j]);
		}
	}
			
	fclose(fp);
	printf("End of writer\n\n\n");
	
}

