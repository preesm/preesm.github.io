#!/bin/sh

mkdir -p bin/make
cd bin/make
# Generating the Makefile
# Run ccmake gui to debug cmake problems
cmake ../.. && make
