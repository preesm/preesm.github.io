# Download Data for Preesm Sobel project

## Option 1: Automated download
Run the `download_dat.sh` from a bash interpreter (eg. Git Bash on windows, any terminal on Linux). 

This should work natively on linux, when generating the C project with Cmake.

## Option 2: Manual download
* Download the font file from here: https://preesm.github.io/assets/downloads/DejaVuSans.ttf
* Download the yuv video file from here : ShakeNDry_1920x1080_120fps_420_8bit_YUV.zip and unzip it directly in the dat folder.