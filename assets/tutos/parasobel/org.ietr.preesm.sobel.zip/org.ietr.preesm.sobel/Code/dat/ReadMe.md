# Resource location
This readme lists the binary resources that are (commonly) needed to run the project.

* [`akiyo_cif`](https://preesm.github.io/assets/downloads/akiyo_cif.7z): YUV video processed by the sobel filter.
* [`DejaVuSans.ttf`](https://preesm.github.io/assets/downloads/DejaVuSans.ttf): Font used in order to display fps information of the application.
