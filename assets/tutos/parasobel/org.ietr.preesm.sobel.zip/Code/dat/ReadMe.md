# Resource location
This readme lists the binary resources that are (commonly) needed to run the project.

* [`akiyo_cif`](http://preesm.sourceforge.net/downloads/akiyo_cif.7z): YUV video processed by the sobel filter.
* [`DejaVuSans.ttf`](http://preesm.sourceforge.net/downloads/DejaVuSans.ttf): Font used in order to display fps information of the application.
