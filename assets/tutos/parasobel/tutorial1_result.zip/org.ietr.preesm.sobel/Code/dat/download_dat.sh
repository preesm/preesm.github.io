#!/bin/bash

function log() {
	echo "$(date +%X) $1"
}

## dowload font
if [ ! -f "DejaVuSans.ttf" ] 
then
	curl -o DejaVuSans.ttf https://preesm.github.io/assets/downloads/DejaVuSans.ttf
fi

# download video
if [ ! -f "ShakeNDry_1920x1080_120fps_420_8bit_YUV.yuv" ] 
then
	if [ ! -f "ShakeNDry_1920x1080_120fps_420_8bit_YUV.zip" ] 
	then
		echo "Downloading archive"
		curl -o ShakeNDry_1920x1080_120fps_420_8bit_YUV.zip https://vaader-data.insa-rennes.fr/data/preesm/assets/ShakeNDry_1920x1080_120fps_420_8bit_YUV.zip
	fi
	unzip -o ShakeNDry_1920x1080_120fps_420_8bit_YUV.zip 
	rm ShakeNDry_1920x1080_120fps_420_8bit_YUV.zip
fi

